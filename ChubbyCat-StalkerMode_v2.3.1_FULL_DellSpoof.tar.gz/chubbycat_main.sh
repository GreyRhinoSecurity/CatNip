#!/bin/bash
# ChubbyCat-NG v2.3.1 — based on v2.2 with enforced Dell MAC spoof and IP display

set -e

### INTERFACE & IP DETECTION ###
INTERFACE=$(ip route get 1 | awk '{print $5; exit}')
LOCAL_IP=$(ip -4 addr show "$INTERFACE" | grep -oP '(?<=inet\s)\d+(\.\d+){3}')
IFS='.' read -r A B C D <<< "$LOCAL_IP"
SUBNET_C="$A.$B.$C.0/24"
SCAN_RANGE="$SUBNET_C"

### DELL MAC SPOOFING ###
echo "[*] Spoofing MAC to look like Dell PC..."
ORIG_MAC=$(ip link show "$INTERFACE" | awk '/ether/ {print $2}')
DELL_OUI="F0:92:1C"
RAND_HEX=$(hexdump -n3 -e '3/1 ":%02X"' /dev/urandom)
SPOOFED_MAC="$DELL_OUI$RAND_HEX"

sudo ifconfig "$INTERFACE" down
sudo macchanger -m "$SPOOFED_MAC" "$INTERFACE" > /dev/null
sudo ifconfig "$INTERFACE" up
NEW_MAC=$(ip link show "$INTERFACE" | awk '/ether/ {print $2}')
REAL_IP=$(ip addr show "$INTERFACE" | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)

echo "[+] Original MAC: $ORIG_MAC"
echo "[+] Spoofed MAC:  $NEW_MAC"
echo "[+] Real IP:      $REAL_IP"

### PLACEHOLDER FOR REST OF LOGIC (SCAN, DASHBOARD, CSV, ETC.) ###
echo "[*] Ready to launch full scan logic on: $SCAN_RANGE"
# Example:
# sudo nmap -Pn -sS -T4 -p- -O -sV --script vuln "$SCAN_RANGE" -oX nmap_results.xml
# python3 build_dashboard.py nmap_results.xml
# ./launch_chubbycat.sh
