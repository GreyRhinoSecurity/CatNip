#!/bin/bash
# ChubbyCat-NG v2.3.1: Dell MAC spoof + IP display + Dashboard launcher

set -e

INTERFACE=$(ip route get 1 | awk '{print $5; exit}')
ORIG_MAC=$(ip link show "$INTERFACE" | awk '/ether/ {print $2}')
DELL_OUI="F0:92:1C"
RAND_HEX=$(hexdump -n3 -e '3/1 ":%02X"' /dev/urandom)
SPOOFED_MAC="$DELL_OUI$RAND_HEX"

sudo ifconfig "$INTERFACE" down
sudo macchanger -m "$SPOOFED_MAC" "$INTERFACE" > /dev/null
sudo ifconfig "$INTERFACE" up

NEW_MAC=$(ip link show "$INTERFACE" | awk '/ether/ {print $2}')
REAL_IP=$(ip addr show "$INTERFACE" | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)

echo "[*] Spoofing MAC to look like Dell PC..."
echo "[+] Original MAC: $ORIG_MAC"
echo "[+] Spoofed MAC:  $NEW_MAC"
echo "[+] Real IP: $REAL_IP"

xdg-open dashboard.html &
xdg-open summary_from_xml.csv &
